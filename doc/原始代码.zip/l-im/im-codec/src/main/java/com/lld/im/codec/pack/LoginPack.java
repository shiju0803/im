package com.lld.im.codec.pack;

import lombok.Data;

/**
 * @description:
 * @author: lld
 * @version: 1.0
 */
@Data
public class LoginPack {

    private String userId;

}
