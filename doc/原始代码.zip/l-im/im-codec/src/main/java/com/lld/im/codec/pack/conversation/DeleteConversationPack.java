package com.lld.im.codec.pack.conversation;

import lombok.Data;

/**
 * @description:
 * @author: lld
 * @version: 1.0
 */
@Data
public class DeleteConversationPack {

    private String conversationId;

}
