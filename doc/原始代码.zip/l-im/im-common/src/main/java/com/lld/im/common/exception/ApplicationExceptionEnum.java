package com.lld.im.common.exception;

public interface ApplicationExceptionEnum {

    int getCode();

    String getError();
}
