package com.lld.im.common.route;

import java.util.List;

/**
 * @description:
 * @author: lld
 * @version: 1.0
 */
public interface RouteHandle {

    public String routeServer(List<String> values,String key);

}
