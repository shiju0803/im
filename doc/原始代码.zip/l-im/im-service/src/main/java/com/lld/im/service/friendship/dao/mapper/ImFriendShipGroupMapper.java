package com.lld.im.service.friendship.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lld.im.service.friendship.dao.ImFriendShipGroupEntity;

public interface ImFriendShipGroupMapper extends BaseMapper<ImFriendShipGroupEntity> {


}
