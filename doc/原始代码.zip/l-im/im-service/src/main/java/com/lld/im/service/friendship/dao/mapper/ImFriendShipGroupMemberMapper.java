package com.lld.im.service.friendship.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lld.im.service.friendship.dao.ImFriendShipGroupMemberEntity;

public interface ImFriendShipGroupMemberMapper extends BaseMapper<ImFriendShipGroupMemberEntity> {


}
