package com.lld.im.service.message.model.resp;

import lombok.Data;

/**
 * @description:
 * @author: lld
 * @version: 1.0
 */
@Data
public class SendMessageResp {

    private Long messageKey;

    private Long messageTime;

}
